var R=require("./chunks/[turbopack]_runtime.js")("server/middleware.js")
R.c("server/chunks/[externals]__12sv8bhnsnvhw._.js")
R.c("server/chunks/[root-of-the-server]__058pumh9r7o2h._.js")
R.m(15838)
module.exports=R.m(15838).exports
