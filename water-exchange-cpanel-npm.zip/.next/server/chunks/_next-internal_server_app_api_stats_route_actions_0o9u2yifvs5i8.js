module.exports=[21894,s=>{"use strict";s.s([])}];

//# sourceMappingURL=_next-internal_server_app_api_stats_route_actions_0o9u2yifvs5i8.js.map