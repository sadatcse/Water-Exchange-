module.exports=[56402,s=>{"use strict";s.s([])}];

//# sourceMappingURL=_next-internal_server_app_api_logs_activity_route_actions_0p2szstnx00ik.js.map