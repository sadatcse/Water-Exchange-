module.exports=[24171,a=>{"use strict";a.s([])}];

//# sourceMappingURL=_next-internal_server_app_legal_termsofuse_page_actions_1tl5t1vd0gsk8.js.map