module.exports=[41977,a=>{"use strict";a.s([])}];

//# sourceMappingURL=_next-internal_server_app_legal_cookiepolicy_page_actions_0vqv0t_u4cd7v.js.map