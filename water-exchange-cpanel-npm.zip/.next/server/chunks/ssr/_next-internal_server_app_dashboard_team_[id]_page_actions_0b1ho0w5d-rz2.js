module.exports=[25167,a=>{"use strict";a.s([])}];

//# sourceMappingURL=_next-internal_server_app_dashboard_team_%5Bid%5D_page_actions_0b1ho0w5d-rz2.js.map