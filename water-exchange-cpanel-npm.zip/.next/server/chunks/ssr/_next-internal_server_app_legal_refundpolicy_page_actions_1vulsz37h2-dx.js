module.exports=[18938,a=>{"use strict";a.s([])}];

//# sourceMappingURL=_next-internal_server_app_legal_refundpolicy_page_actions_1vulsz37h2-dx.js.map