module.exports=[72139,a=>{"use strict";var b=a.i(30669);a.s(["f",0,function(){return(0,b.f)("/product-categories",{initialData:[],select:a=>a.data})}])}];

//# sourceMappingURL=src_hooks_useProductCategories_1v8obpck3w_di.js.map