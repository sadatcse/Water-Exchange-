module.exports=[40785,a=>{"use strict";a.s([])}];

//# sourceMappingURL=_next-internal_server_app_legal_appprivacypolicy_page_actions_02c4pxj-uki2a.js.map