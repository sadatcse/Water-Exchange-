module.exports=[42684,a=>{"use strict";let b=["Water Treatment","Compliance","Waste Management","Research","Events","Energy","Training"],c=b.map(a=>({value:a,label:a}));a.s(["U",0,b,"n",0,c])}];

//# sourceMappingURL=src_config_blog_0ugxin0m_cpql.js.map