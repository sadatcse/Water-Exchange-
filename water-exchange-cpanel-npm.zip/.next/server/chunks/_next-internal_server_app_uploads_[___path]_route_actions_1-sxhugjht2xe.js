module.exports=[10612,s=>{"use strict";s.s([])}];

//# sourceMappingURL=_next-internal_server_app_uploads_%5B___path%5D_route_actions_1-sxhugjht2xe.js.map