module.exports=[69019,s=>{"use strict";s.s([])}];

//# sourceMappingURL=_next-internal_server_app_api_clients_%5Bid%5D_route_actions_0hwxi2sn-0_5e.js.map