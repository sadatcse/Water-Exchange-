module.exports=[5904,s=>{"use strict";s.s([])}];

//# sourceMappingURL=_next-internal_server_app_api_product-categories_route_actions_13brc31davvk5.js.map