module.exports=[12860,s=>{"use strict";s.s([])}];

//# sourceMappingURL=_next-internal_server_app_api_reports_state_route_actions_1c-8q7e2fqjav.js.map