module.exports=[84625,s=>{"use strict";s.s([])}];

//# sourceMappingURL=1oeh_server_app_api_product-categories_%5Bid%5D_route_actions_027zr5i06c5f3.js.map