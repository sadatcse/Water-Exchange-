module.exports=[9620,s=>{"use strict";s.s([])}];

//# sourceMappingURL=_next-internal_server_app_api_auth_password_route_actions_1qvu66h4-vhg7.js.map