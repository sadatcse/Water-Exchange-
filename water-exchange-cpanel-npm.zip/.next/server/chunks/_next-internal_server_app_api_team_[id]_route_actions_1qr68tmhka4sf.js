module.exports=[10794,s=>{"use strict";s.s([])}];

//# sourceMappingURL=_next-internal_server_app_api_team_%5Bid%5D_route_actions_1qr68tmhka4sf.js.map