module.exports=[7285,s=>{"use strict";let t=(0,s.i(52811).F)("visitor_logs");s.s(["f",0,t])}];

//# sourceMappingURL=src_models_VisitorLog_1jffi9vg-qstu.js.map