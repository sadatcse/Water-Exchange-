var R=require("../../chunks/[turbopack]_runtime.js")("server/app/apple-icon.png/route.js")
R.c("server/chunks/[externals]__1v_1_f8o7hvkx._.js")
R.c("server/chunks/[root-of-the-server]__1r7kbfkiw2xmu._.js")
R.c("server/chunks/_013mswtsyfnoo._.js")
R.c("server/chunks/_next-internal_server_app_apple-icon_png_route_actions_0jcl8aui56a1m.js")
R.m(94252)
module.exports=R.m(94252).exports
