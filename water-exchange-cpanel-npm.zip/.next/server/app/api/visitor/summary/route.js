var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/visitor/summary/route.js")
R.c("server/chunks/[root-of-the-server]__1_po5zt4lvu-u._.js")
R.c("server/chunks/src_lib_table_0mcl03939uvsb.js")
R.c("server/chunks/[root-of-the-server]__1r7kbfkiw2xmu._.js")
R.c("server/chunks/_0w_ybj3vjy5x_._.js")
R.c("server/chunks/_next-internal_server_app_api_visitor_summary_route_actions_11u5zzjfcucb6.js")
R.m(70852)
module.exports=R.m(70852).exports
