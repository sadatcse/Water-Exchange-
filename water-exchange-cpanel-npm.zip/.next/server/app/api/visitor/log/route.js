var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/visitor/log/route.js")
R.c("server/chunks/[root-of-the-server]__0w-u_dnzmkp5c._.js")
R.c("server/chunks/src_lib_table_0mcl03939uvsb.js")
R.c("server/chunks/_0r92-ydw_aq4x._.js")
R.c("server/chunks/[root-of-the-server]__1r7kbfkiw2xmu._.js")
R.c("server/chunks/_next-internal_server_app_api_visitor_log_route_actions_1gkoicsj630mz.js")
R.m(11044)
module.exports=R.m(11044).exports
