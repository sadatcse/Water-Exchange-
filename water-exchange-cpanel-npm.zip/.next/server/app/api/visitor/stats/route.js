var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/visitor/stats/route.js")
R.c("server/chunks/[root-of-the-server]__0lvolzcbzaxco._.js")
R.c("server/chunks/src_lib_table_0mcl03939uvsb.js")
R.c("server/chunks/_04dvs4h6cwmpn._.js")
R.c("server/chunks/[root-of-the-server]__1r7kbfkiw2xmu._.js")
R.c("server/chunks/_08whnyg9tf8f4._.js")
R.c("server/chunks/_next-internal_server_app_api_visitor_stats_route_actions_0r0ffiutu64l2.js")
R.m(36870)
module.exports=R.m(36870).exports
