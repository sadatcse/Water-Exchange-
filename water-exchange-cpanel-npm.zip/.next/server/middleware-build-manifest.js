globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/0cz1d0mv5g_q7.js"
  ],
  "lowPriorityFiles": [
    "static/f9ZB4hBlOyR4cRs-6SzIP/_buildManifest.js",
    "static/f9ZB4hBlOyR4cRs-6SzIP/_ssgManifest.js",
    "static/f9ZB4hBlOyR4cRs-6SzIP/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/1ckvzn7sfprko.js",
    "static/chunks/1-nqmp1rl8kqt.js",
    "static/chunks/1e2ol62p06em5.js",
    "static/chunks/1mbc05r6h_wqf.js",
    "static/chunks/turbopack-3-ry682tkyiqk.js"
  ],
  "rootMainFilesTree": {},
  "pagesChunkGroupBootstrapParams": {
    "/page": {
      "otherChunks": [
        "static/chunks/1ckvzn7sfprko.js",
        "static/chunks/1-nqmp1rl8kqt.js",
        "static/chunks/1e2ol62p06em5.js",
        "static/chunks/1mbc05r6h_wqf.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/_not-found/page": {
      "otherChunks": [
        "static/chunks/1ckvzn7sfprko.js",
        "static/chunks/1-nqmp1rl8kqt.js",
        "static/chunks/1e2ol62p06em5.js",
        "static/chunks/1mbc05r6h_wqf.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/_global-error/page": {
      "otherChunks": [
        "static/chunks/1ckvzn7sfprko.js",
        "static/chunks/1-nqmp1rl8kqt.js",
        "static/chunks/1e2ol62p06em5.js",
        "static/chunks/1mbc05r6h_wqf.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/about/page": {
      "otherChunks": [
        "static/chunks/1ckvzn7sfprko.js",
        "static/chunks/1-nqmp1rl8kqt.js",
        "static/chunks/1e2ol62p06em5.js",
        "static/chunks/1mbc05r6h_wqf.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/admin/page": {
      "otherChunks": [
        "static/chunks/1ckvzn7sfprko.js",
        "static/chunks/1-nqmp1rl8kqt.js",
        "static/chunks/1e2ol62p06em5.js",
        "static/chunks/1mbc05r6h_wqf.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/blog/page": {
      "otherChunks": [
        "static/chunks/1ckvzn7sfprko.js",
        "static/chunks/1-nqmp1rl8kqt.js",
        "static/chunks/1e2ol62p06em5.js",
        "static/chunks/1mbc05r6h_wqf.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/blog/[slug]/page": {
      "otherChunks": [
        "static/chunks/1ckvzn7sfprko.js",
        "static/chunks/1-nqmp1rl8kqt.js",
        "static/chunks/1e2ol62p06em5.js",
        "static/chunks/1mbc05r6h_wqf.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/clients/page": {
      "otherChunks": [
        "static/chunks/1ckvzn7sfprko.js",
        "static/chunks/1-nqmp1rl8kqt.js",
        "static/chunks/1e2ol62p06em5.js",
        "static/chunks/1mbc05r6h_wqf.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/contact/page": {
      "otherChunks": [
        "static/chunks/1ckvzn7sfprko.js",
        "static/chunks/1-nqmp1rl8kqt.js",
        "static/chunks/1e2ol62p06em5.js",
        "static/chunks/1mbc05r6h_wqf.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/dashboard/page": {
      "otherChunks": [
        "static/chunks/1ckvzn7sfprko.js",
        "static/chunks/1-nqmp1rl8kqt.js",
        "static/chunks/1e2ol62p06em5.js",
        "static/chunks/1mbc05r6h_wqf.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/dashboard/activity/page": {
      "otherChunks": [
        "static/chunks/1ckvzn7sfprko.js",
        "static/chunks/1-nqmp1rl8kqt.js",
        "static/chunks/1e2ol62p06em5.js",
        "static/chunks/1mbc05r6h_wqf.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/dashboard/blog/page": {
      "otherChunks": [
        "static/chunks/1ckvzn7sfprko.js",
        "static/chunks/1-nqmp1rl8kqt.js",
        "static/chunks/1e2ol62p06em5.js",
        "static/chunks/1mbc05r6h_wqf.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/dashboard/blog/[id]/page": {
      "otherChunks": [
        "static/chunks/1ckvzn7sfprko.js",
        "static/chunks/1-nqmp1rl8kqt.js",
        "static/chunks/1e2ol62p06em5.js",
        "static/chunks/1mbc05r6h_wqf.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/dashboard/blog/new/page": {
      "otherChunks": [
        "static/chunks/1ckvzn7sfprko.js",
        "static/chunks/1-nqmp1rl8kqt.js",
        "static/chunks/1e2ol62p06em5.js",
        "static/chunks/1mbc05r6h_wqf.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/dashboard/clients/page": {
      "otherChunks": [
        "static/chunks/1ckvzn7sfprko.js",
        "static/chunks/1-nqmp1rl8kqt.js",
        "static/chunks/1e2ol62p06em5.js",
        "static/chunks/1mbc05r6h_wqf.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/dashboard/clients/[id]/page": {
      "otherChunks": [
        "static/chunks/1ckvzn7sfprko.js",
        "static/chunks/1-nqmp1rl8kqt.js",
        "static/chunks/1e2ol62p06em5.js",
        "static/chunks/1mbc05r6h_wqf.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/dashboard/clients/new/page": {
      "otherChunks": [
        "static/chunks/1ckvzn7sfprko.js",
        "static/chunks/1-nqmp1rl8kqt.js",
        "static/chunks/1e2ol62p06em5.js",
        "static/chunks/1mbc05r6h_wqf.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/dashboard/login-history/page": {
      "otherChunks": [
        "static/chunks/1ckvzn7sfprko.js",
        "static/chunks/1-nqmp1rl8kqt.js",
        "static/chunks/1e2ol62p06em5.js",
        "static/chunks/1mbc05r6h_wqf.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/dashboard/media/page": {
      "otherChunks": [
        "static/chunks/1ckvzn7sfprko.js",
        "static/chunks/1-nqmp1rl8kqt.js",
        "static/chunks/1e2ol62p06em5.js",
        "static/chunks/1mbc05r6h_wqf.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/dashboard/messages/page": {
      "otherChunks": [
        "static/chunks/1ckvzn7sfprko.js",
        "static/chunks/1-nqmp1rl8kqt.js",
        "static/chunks/1e2ol62p06em5.js",
        "static/chunks/1mbc05r6h_wqf.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/dashboard/product-categories/page": {
      "otherChunks": [
        "static/chunks/1ckvzn7sfprko.js",
        "static/chunks/1-nqmp1rl8kqt.js",
        "static/chunks/1e2ol62p06em5.js",
        "static/chunks/1mbc05r6h_wqf.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/dashboard/products/page": {
      "otherChunks": [
        "static/chunks/1ckvzn7sfprko.js",
        "static/chunks/1-nqmp1rl8kqt.js",
        "static/chunks/1e2ol62p06em5.js",
        "static/chunks/1mbc05r6h_wqf.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/dashboard/products/[id]/page": {
      "otherChunks": [
        "static/chunks/1ckvzn7sfprko.js",
        "static/chunks/1-nqmp1rl8kqt.js",
        "static/chunks/1e2ol62p06em5.js",
        "static/chunks/1mbc05r6h_wqf.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/dashboard/products/new/page": {
      "otherChunks": [
        "static/chunks/1ckvzn7sfprko.js",
        "static/chunks/1-nqmp1rl8kqt.js",
        "static/chunks/1e2ol62p06em5.js",
        "static/chunks/1mbc05r6h_wqf.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/dashboard/settings/page": {
      "otherChunks": [
        "static/chunks/1ckvzn7sfprko.js",
        "static/chunks/1-nqmp1rl8kqt.js",
        "static/chunks/1e2ol62p06em5.js",
        "static/chunks/1mbc05r6h_wqf.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/dashboard/team/page": {
      "otherChunks": [
        "static/chunks/1ckvzn7sfprko.js",
        "static/chunks/1-nqmp1rl8kqt.js",
        "static/chunks/1e2ol62p06em5.js",
        "static/chunks/1mbc05r6h_wqf.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/dashboard/team/[id]/page": {
      "otherChunks": [
        "static/chunks/1ckvzn7sfprko.js",
        "static/chunks/1-nqmp1rl8kqt.js",
        "static/chunks/1e2ol62p06em5.js",
        "static/chunks/1mbc05r6h_wqf.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/dashboard/team/new/page": {
      "otherChunks": [
        "static/chunks/1ckvzn7sfprko.js",
        "static/chunks/1-nqmp1rl8kqt.js",
        "static/chunks/1e2ol62p06em5.js",
        "static/chunks/1mbc05r6h_wqf.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/dashboard/traffic/page": {
      "otherChunks": [
        "static/chunks/1ckvzn7sfprko.js",
        "static/chunks/1-nqmp1rl8kqt.js",
        "static/chunks/1e2ol62p06em5.js",
        "static/chunks/1mbc05r6h_wqf.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/expertise/page": {
      "otherChunks": [
        "static/chunks/1ckvzn7sfprko.js",
        "static/chunks/1-nqmp1rl8kqt.js",
        "static/chunks/1e2ol62p06em5.js",
        "static/chunks/1mbc05r6h_wqf.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/faq/page": {
      "otherChunks": [
        "static/chunks/1ckvzn7sfprko.js",
        "static/chunks/1-nqmp1rl8kqt.js",
        "static/chunks/1e2ol62p06em5.js",
        "static/chunks/1mbc05r6h_wqf.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/legal/appprivacypolicy/page": {
      "otherChunks": [
        "static/chunks/1ckvzn7sfprko.js",
        "static/chunks/1-nqmp1rl8kqt.js",
        "static/chunks/1e2ol62p06em5.js",
        "static/chunks/1mbc05r6h_wqf.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/legal/cookiepolicy/page": {
      "otherChunks": [
        "static/chunks/1ckvzn7sfprko.js",
        "static/chunks/1-nqmp1rl8kqt.js",
        "static/chunks/1e2ol62p06em5.js",
        "static/chunks/1mbc05r6h_wqf.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/legal/refundpolicy/page": {
      "otherChunks": [
        "static/chunks/1ckvzn7sfprko.js",
        "static/chunks/1-nqmp1rl8kqt.js",
        "static/chunks/1e2ol62p06em5.js",
        "static/chunks/1mbc05r6h_wqf.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/legal/termsofuse/page": {
      "otherChunks": [
        "static/chunks/1ckvzn7sfprko.js",
        "static/chunks/1-nqmp1rl8kqt.js",
        "static/chunks/1e2ol62p06em5.js",
        "static/chunks/1mbc05r6h_wqf.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/products/page": {
      "otherChunks": [
        "static/chunks/1ckvzn7sfprko.js",
        "static/chunks/1-nqmp1rl8kqt.js",
        "static/chunks/1e2ol62p06em5.js",
        "static/chunks/1mbc05r6h_wqf.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/products/[slug]/page": {
      "otherChunks": [
        "static/chunks/1ckvzn7sfprko.js",
        "static/chunks/1-nqmp1rl8kqt.js",
        "static/chunks/1e2ol62p06em5.js",
        "static/chunks/1mbc05r6h_wqf.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/services/page": {
      "otherChunks": [
        "static/chunks/1ckvzn7sfprko.js",
        "static/chunks/1-nqmp1rl8kqt.js",
        "static/chunks/1e2ol62p06em5.js",
        "static/chunks/1mbc05r6h_wqf.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    }
  },
  "chunkLoadingGlobal": "TURBOPACK"
};
