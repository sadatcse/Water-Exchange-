// Checks that the website can sign in to its MariaDB database. In cPanel → Terminal, inside the app folder:
//   node check-db.js
const fs = require('node:fs');
const path = require('node:path');

const envFile = path.join(__dirname, '.env');
if (fs.existsSync(envFile))
  for (const line of fs.readFileSync(envFile, 'utf8').split(/\r?\n/)) {
    const m = line.match(/^\s*([A-Z0-9_]+)\s*=\s*(.*)\s*$/);
    if (m) process.env[m[1]] = m[2].replace(/^(['"])(.*)\1$/, '$2');
  }
const { DB_HOST = 'localhost', DB_PORT = '3306', DB_USER, DB_PASSWORD = '', DB_NAME } = process.env;
if (!DB_USER || !DB_NAME) {
  console.log('✖ DB_USER / DB_NAME are not set — add them to .env (or Setup Node.js App → Environment variables).');
  process.exit(1);
}

(async () => {
  const mysql = require('mysql2/promise');
  let conn;
  try {
    conn = await mysql.createConnection({ host: DB_HOST, port: Number(DB_PORT), user: DB_USER, password: DB_PASSWORD, database: DB_NAME, connectTimeout: 10000 });
    const [[row]] = await conn.query('SELECT VERSION() AS version, CURRENT_USER() AS user');
    const [tables] = await conn.query('SHOW TABLES');
    console.log('✔ Signed in as', row.user, '—', row.version);
    console.log('  ' + tables.length + ' table(s) in ' + DB_NAME + (tables.length ? '' : ' (the website creates them on its first start)'));
    for (const t of tables) {
      const name = Object.values(t)[0];
      const [[{ n }]] = await conn.query('SELECT COUNT(*) AS n FROM `' + name + '`');
      console.log('   ', name + ':', n);
    }
  } catch (e) {
    console.log('✖', e.code || '', e.message);
    if (e.code === 'ER_ACCESS_DENIED_ERROR') console.log('  → wrong DB_USER / DB_PASSWORD (cPanel → MySQL Databases)');
    if (e.code === 'ER_DBACCESS_DENIED_ERROR') console.log('  → add the user to the database: MySQL Databases → Add User To Database → ALL PRIVILEGES');
    if (e.code === 'ER_BAD_DB_ERROR') console.log('  → DB_NAME does not exist (cPanel → MySQL Databases)');
    process.exit(1);
  } finally {
    await conn?.end().catch(() => {});
  }
})();
