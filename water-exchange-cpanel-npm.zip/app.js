// cPanel / Passenger startup file — starts the Next.js server from ./.next
// Settings (DB_USER, JWT_SECRET, …) come from Setup Node.js App → Environment variables; a .env file next
// to this one is read too, without overriding those.
const fs = require('node:fs');
const path = require('node:path');
const { createServer } = require('node:http');

const envFile = path.join(__dirname, '.env');
if (fs.existsSync(envFile))
  for (const line of fs.readFileSync(envFile, 'utf8').split(/\r?\n/)) {
    const m = line.match(/^\s*([A-Z0-9_]+)\s*=\s*(.*)\s*$/);
    if (m && process.env[m[1]] === undefined) process.env[m[1]] = m[2].replace(/^(['"])(.*)\1$/, '$2');
  }
process.env.NODE_ENV = 'production';
process.env.NEXT_OUTPUT = 'default';
// Dashboard uploads live next to app.js, outside .next, so replacing .next on an update keeps them
process.env.UPLOAD_DIR = process.env.UPLOAD_DIR || path.join(__dirname, 'uploads');
fs.mkdirSync(process.env.UPLOAD_DIR, { recursive: true });
// Data from the old MongoDB database, imported once into the empty tables (then renamed .imported-…)
process.env.DATA_IMPORT_FILE = path.join(__dirname, 'mongo-export.json');

for (const key of ["DB_USER","DB_NAME","JWT_SECRET","SETTINGS_SECRET","CRON_SECRET"])
  if (!process.env[key]) console.error('✖ ' + key + ' is not set — add it to .env or Setup Node.js App → Environment variables');

const next = require('next');
const app = next({ dev: false, dir: __dirname });
const handle = app.getRequestHandler();
// Passenger passes PORT (sometimes a socket path, so it isn't parsed as a number)
const port = process.env.PORT || 3000;
app
  .prepare()
  .then(() => createServer((req, res) => handle(req, res)).listen(port, () => console.log('> Ready on ' + port)))
  .catch((err) => {
    console.error(err);
    process.exit(1);
  });
